function [b, a]  = wahfilter(fc, fs, Rp)
%
% Derive coefficients for a quadratic filter with a given
% cutoff frequency and quality factor. 
%
% Usage:     [B,A] = wahfilter(fc, fs, Rp);
%
%            Fc is the center frequency
%            Fs is the sampling rate
%            Rp is the quality factor, 0.98 is a typical value
%

if nargin<3
  Rp=0.98;
end

b=[1 0 -1];
a=[1 -2*Rp*cos(2*pi*fc/fs) Rp^2];
