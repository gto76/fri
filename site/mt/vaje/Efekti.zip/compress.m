function w=compress(w,sr,threshDB,ratio)
% function wc=compress(w,thresh,ratio)
%  simple compression of w 
%    thresh in (dB) is the compression threshold
%    ratio is the compression ratio e.g. 1/4 means 1:4 compression

% from dB to magnitude
thresh=10^(threshDB/20);

% store max value
wMax=max(abs(w));

%low-pass filter for amplitude envelope calculation
[B,A]=butter(2,100/(sr/2));
% filter the power signal
wPow=w.*w;
wFilt=filtfilt(B,A,wPow);
% convert back to magnitude
wFilt(wFilt<0)=0;
wFilt=sqrt(wFilt);

% find region over threshold
idx=wFilt>thresh;

% calculate multiplication factor
factor=ones(size(w));
factor(idx)= (thresh./wFilt(idx)).^(1.0-ratio);

% transform w with factor
w=w.*factor;

% restore old maximum
w=w/max(abs(w))*wMax;
