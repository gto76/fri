function [b, a]  = peak(G, fc, fs)
%
% Derive coefficients for a peak filter with a given amplitude and
% cutoff frequency.  All coefficients are calculated as described in 
% Zolzer's DAFX book (p. 50 -55).  
%
% Usage:     [B,A] = peak(G, Fc, Fs);
%
%            G is the logrithmic gain (in dB)
%            Fc is the center frequency
%            Fs is the sampling rate
%
% Author:    Jeff Tackett 08/22/05
%

K = tan((pi * fc)/fs);
V0 = 10^(G/20);
Q=sqrt(2);  
root2 = 1/Q; %sqrt(2)

%Invert gain if a cut
if(V0 < 1)
    V0 = 1/V0;
end

if ( G > 0 ) % boost
   
    b0 = (1 + V0*root2*K + K^2) / (1 + root2*K + K^2);
    b1 =       (2 * (K^2 - 1) ) / (1 + root2*K + K^2);
    b2 = (1 - V0*root2*K + K^2) / (1 + root2*K + K^2);
    a1 =       (2 * (K^2 - 1) ) / (1 + root2*K + K^2);
    a2 =    (1 - root2*K + K^2) / (1 + root2*K + K^2);

elseif ( G < 0 ) % cut
    
    b0 = (1 + root2*K + K^2) / (1 + V0*root2*K + K^2);
    b1 =       (2 * (K^2 - 1) ) / (1 + V0*root2*K + K^2);
    b2 = (1 - root2*K + K^2) / (1 + V0*root2*K + K^2);
    a1 =       (2 * (K^2 - 1) ) / (1 + V0*root2*K + K^2);
    a2 =    (1 - V0*root2*K + K^2) / (1 + V0*root2*K + K^2);

else
    b0 = V0;
    b1 = 0;
    b2 = 0;
    a1 = 0;
    a2 = 0;
end

%return values
a = [  1, a1, a2];
b = [ b0, b1, b2];
