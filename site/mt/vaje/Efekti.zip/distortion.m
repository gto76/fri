function wo = distortion(w,type,alpha)
% function wo = distortion(w,type,alpha)
% type = overdrive or distortion
% alpha - coefficient of distortion

if nargin<3
  alpha=-10;
end

if strcmp(type,'overdrive')==1 
  th=1/3; 
  wabs=abs(w); % ignore sign
  
  wabs(wabs>=2*th)=1;
  wabs(wabs<2*th & wabs>=th)=(3-(2-3*wabs(wabs<2*th & wabs>=th)).^2)/3;
  wabs(wabs<th)=2*wabs(wabs<th);
  
  wo=wabs.*sign(w); % restore sign
else
  % distortion
  wo=sign(w).*(1-exp(alpha*abs(w)));
end