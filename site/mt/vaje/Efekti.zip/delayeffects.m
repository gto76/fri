function y=delayeffects(x,sr,effect)
% function y=delayeffects(x,sr,effect)
%   x is the input signal
%   sr is the sample rate
%   effect is vibrato, flanger, chorus or echo

if (strcmp(effect,'vibrato')==1)
  % example of vibrato parameters
  Kmin=0;
  Kmax=0.005; 
  Kfreq=8;
  BL=0;
  FF=1;
  FB=0;
  mod='sin';
elseif (strcmp(effect,'flanger')==1)
  % example of flanger parameters
  Kmin=0.0;
  Kmax=0.01; 
  Kfreq=0.3;
  BL=0.7;
  FF=0.7;
  FB=0.7;
  mod='sin';
elseif (strcmp(effect,'chorus')==1)
  % example of chorus parameters
  Kmin=0.005;
  Kmax=0.03; 
  BL=0.7;
  FF=1;
  FB=-0.7;
  mod='rand';
elseif (strcmp(effect,'echo')==1)
  % example of echo parameters
  Kmin=0.05;
  Kmax=0.2; 
  BL=0.7;
  FF=0.7;
  FB=0;
  mod='rand';
end

if (strcmp(mod,'sin')==1) % sinusoidal modulation
  K=0.5*(sin(2*pi*Kfreq*(1:length(x))/sr)+1)*(Kmax-Kmin)+Kmin;
else % random
  K=repmat(rand(1)*(Kmax-Kmin)+Kmin,1,length(x));
end
K=K*sr;
maxK=ceil(max(K));

x=[zeros(maxK-1,1); x(:)];
y=x;
for n=maxK:length(y);
  sample=max(1,n-K(n-maxK+1));
  i=floor(sample);  
  frac=sample-i;
  xi=x(i+1)*frac+x(i)*(1-frac); 
  yi=y(i+1)*frac+y(i)*(1-frac); 
  
  y(n)=BL*x(n)+FF*xi+FB*yi;
end 

y=s1(y(maxK:end));

