function out=moogFilter(in, fs, cutoff, res)
% out=moogFilter(in, fs, cutoff, resonance)
% in = input signal
% cutoff = cutoff freq in Hz
% fs = sampling frequency //(e.g. 44100Hz)
% res = resonance [0 - 1] //(minimum - maximum)

f = 2 * cutoff / fs; %[0 - 1]
k = 3.6*f - 1.6*f*f -1; %(Empirical tunning)
p = (k+1)*0.5;
scale = exp((1-p)*1.386249);
r = res*scale;

oldx=0; oldy1=0; oldy2=0; oldy3=0;
y1=0; y2=0; y3=0; y4=0;
out=in;

%Loop
for i=1:length(in)
%--Inverted feed back for corner peaking
  x = in(i) - r*y4;

%Four cascaded onepole filters (bilinear transform)
  y1=x*p + oldx*p - k*y1;
  y2=y1*p+oldy1*p - k*y2;
  y3=y2*p+oldy2*p - k*y3;
  y4=y3*p+oldy3*p - k*y4;

  %Clipper band limited sigmoid
  y4 = y4 - (y4^3)/6;

  out(i)=y4;
  
  oldx = x;
  oldy1 = y1;
  oldy2 = y2;
  oldy3 = y3;  
end
